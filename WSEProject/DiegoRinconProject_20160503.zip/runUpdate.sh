#!/bin/bash


java -cp .:classes/:lib/* nyu.crawler.update.Update "$@"
