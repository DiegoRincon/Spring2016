#!/bin/bash

dir=classes

mkdir $dir
cp log4j2.xml $dir/
javac -cp .:lib/* -d $dir $(find src -name "*.java")
