#!/bin/bash


java -cp .:classes/:lib/* nyu.crawler.retriever.Retriever "$@"
