#!/bin/bash


java -cp .:classes/:lib/* nyu.crawler.crawler.Crawler "$@"
