package nyu.crawler.data;
import lombok.AllArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@ToString
public class Interval {
	public int start;
	public int end;
}
