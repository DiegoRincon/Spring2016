#!/bin/bash

cd classes

java -cp .:../lib/* nyu.crawler.update.Update "$@"
