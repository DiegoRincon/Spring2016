Name: Diego F. Rincon Santana

How to compile:

From the root directory (where the build.xml file is), run the command 'ant
compile' (without quotes). If ant is not installed, run the compile.sh script.

How to run Crawler:

Once you have compiled it, run the runCrawler.sh script with the usual
parameters. Run with -h or --help flag for usage.

How to run Update:

Once you have compiled it, run the runUpdate.sh script with the required
parameters. Please note that all arguments are optional, to see usage run it
with -h or --help flag for usage.

How to run Retriever:

Once you have compiled it, run the runRetriever.sh script with the required
parameters. No flags are set, the usage is: <indexPath> <queries>...
